//main
document.querySelector("button").addEventListener("click", runTest);

function runTest() {
  const TOTAL_NUMBERS = 1024 * 1024 * 10;
  const NUM_WORKERS = 4;
  var numbersToCheck = TOTAL_NUMBERS,
    primesFound = 0;
  var buffer = new SharedArrayBuffer(numbersToCheck); // reserves 10 MB
  var view = new Uint8Array(buffer); // view the buffer as bytes

  var tasks = [];
  var numTasks = 0;
  var tasksCompleted = 0;

  var pool = [];
  var numWorkersReady = 0;
  var workersReady = false;

  performance.mark("testStart");
  var offset = 0;
  while (numbersToCheck) {
    var blockLen = Math.min(numbersToCheck, TOTAL_NUMBERS / NUM_WORKERS);
    tasks.push({ command: "run", offset: offset, length: blockLen });
    numbersToCheck -= blockLen;
    offset += blockLen;
  }

  numTasks = tasks.length;

  function run() {
    console.time("prime-run");
    for (var i = 0; i < NUM_WORKERS; i++) {
      var task = tasks.shift();
      pool[i].postMessage(task);
    }
  }

  //worker pool
  console.time("pool-init");
  for (var i = 0; i < NUM_WORKERS; i++) {
    var worker = new Worker("prime-worker.js");
    pool.push(worker);
    worker.postMessage({ command: "init", data: buffer });
    worker.onmessage = function (msg) {
      switch (msg.data.echo) {
        case "initialized":
          numWorkersReady++;
          if (numWorkersReady === NUM_WORKERS) {
            console.timeEnd("pool-init");
            workersReady = true;
            console.log({ workersReady });
            run();
          }
          break;

        case "result":
          primesFound += msg.data.numPrimes;
          tasksCompleted++;
          if (tasksCompleted === numTasks) {
            console.timeEnd("prime-run");
            performance.mark("testEnd");
            performance.measure("runTest", "testStart", "testEnd");
            var timeTaken = performance.getEntriesByName("runTest")[0].duration;
            alert(`Done. Found ${primesFound} primes in ${timeTaken} ms`);
            console.log(primesFound, view);
          } else {
            if (tasks.length > 0) {
              var task = tasks.shift();
              this.postMessage(task);
            }
          }
          break;
        default:
          break;
      }
    };
  }
}
